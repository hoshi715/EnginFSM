﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraManager : MonoBehaviour {

    [SerializeField] GameObject MainCamera;
    [SerializeField] GameObject SubCamera;
    [SerializeField] GameObject CharBody;

	void Start ()
    {
        UseMainCamera();
	}
	
	void Update ()
    {
		if(Input.GetKeyDown(KeyCode.Tab))
        {
            if (MainCamera.active) { UseSubCamera(); }
            else { UseMainCamera(); }
        }
    }

    void UseMainCamera()
    {
        MainCamera.SetActive(true);
        CharBody.SetActive(true);
        SubCamera.SetActive(false);
    }

    void UseSubCamera()
    {
        MainCamera.SetActive(false);
        CharBody.SetActive(false);
        SubCamera.SetActive(true);
    }
}
