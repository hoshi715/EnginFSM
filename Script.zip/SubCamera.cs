﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SubCamera : MonoBehaviour {


    void Update ()
    {
        float Hor = Input.GetAxis("Horizontal");
        transform.Rotate(0, Hor, 0);
    }
}
