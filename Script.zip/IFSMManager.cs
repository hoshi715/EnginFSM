﻿
public interface IFSMManager
{
    void SetDeadState();
    void SetRunState();
    void NotifyTargetKilled();
}

